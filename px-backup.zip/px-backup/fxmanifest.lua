fx_version 'cerulean'
games { 'gta5' }
author 'NAT2K15 Development'

server_scripts {
    'index.js'
}